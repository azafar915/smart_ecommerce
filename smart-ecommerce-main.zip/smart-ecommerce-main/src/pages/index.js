import HeroImage from "@/components/heroImage";

function HomePage() {
  return(
    <HeroImage />
  )
}

export default HomePage;