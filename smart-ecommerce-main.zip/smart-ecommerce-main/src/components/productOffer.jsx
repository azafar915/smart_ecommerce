function ProductOffer() {
    return(
        <div className="padding-top-100">
            <div className="row">
                <div className="col-sm-4">
                    <img src="cellphones.jpg" style={{height: "250px"}}/>
                </div>
                <div className="col-sm-8">
                    Detailed
                </div>
            </div>
            <div className="row">
                <div className="col-sm-8 offset-sm-4 padding-top-100">
                    Offers
                </div>
            </div>
        </div>
    )
}

export default ProductOffer;